<?php $__env->startSection('title'); ?>
    Insert Checkpoint
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">
        <div class="col-sm-6 text-left p-5">

            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>Insert checkpoint</h3>
            <p><strong>Shipment Details:</strong></p>
            <p>
                <strong>Tracking ID:</strong> <?php echo e($shipment->tracking_id); ?><br>
                <strong>Origin:</strong> <?php echo e($shipment->origin); ?><br>
                <strong>Destination:</strong> <?php echo e($shipment->destination); ?><br>
                <strong>Name of User:</strong> <?php echo e($shipment->user->name); ?><br>
            </p>

            <form method="post" action="<?php echo e(action('ShipmentHistoryController@submitCheckpoint', $shipment->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Current Location</label>
                    <input name="location" class="form-control" type="text" placeholder="Current Location" required>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <textarea class="form-control" name="status" placeholder="Status of Shipment in this location" required>

                    </textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/controlpanel/shipments/insert-checkpoint.blade.php ENDPATH**/ ?>