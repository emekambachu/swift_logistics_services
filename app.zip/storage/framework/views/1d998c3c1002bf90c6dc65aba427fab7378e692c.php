<?php $__env->startSection('title'); ?>
    Dashboard
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-lg-12 text-center p-5">

            <h3>Manage your shipments, parcel and users through the menus</h3>































        </div>

    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/controlpanel/index.blade.php ENDPATH**/ ?>