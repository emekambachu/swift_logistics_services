<?php $__env->startSection('title'); ?>
    Shipment History
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="breadcrumb-area  margin-bottom-20" style="background-image:url(<?php echo e(asset('assets/img/breadcrumb/01.png')); ?>);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-inner">
                        <h2 class="page-title">Shipment History</h2>
                        <ul class="page-list">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('track-shipment')); ?>">Track Shipment</a></li>
                            <li><a>Shipment History</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 col-md-12 col-lg-12" style="padding-bottom: 50px;">

        <table class="table table-dark">
            <tbody>
            <tr>
                <td><strong>Recipient Name:</strong> <?php echo e($shipment->user->name); ?> </td>
                <td><strong>Recipient Email:</strong> <?php echo e($shipment->user->email); ?></td>
                <td><strong>Recipient Mobile:</strong> <?php echo e($shipment->user->mobile); ?></td>
            </tr>
            <tr>
                <td><strong>Parcel Name:</strong> <?php echo e($shipment->parcel->name); ?> </td>
                <td><strong>Parcel Weight:</strong> <?php echo e($shipment->parcel->weight); ?>KG</td>
                <td><strong>Parcel Description:</strong> <?php echo e($shipment->parcel->description); ?></td>
            </tr>
            <tr>
                <td><strong>Tracking ID:</strong> <?php echo e($shipment->tracking_id); ?></td>
                <td><strong>Shipment Origin:</strong> <?php echo e($shipment->origin); ?></td>
                <td><strong>Shipment Destination:</strong> <?php echo e($shipment->destination); ?></td>
            </tr>
            <tr>
                <td><strong>Shipment Date:</strong> <?php echo e(date('jS \of F Y', strtotime($shipment->created_at))); ?></td>
                <td><strong>Last Shipment Date:</strong>
                    <?php if(!empty($lastCheckpoint->created_at)): ?>
                        <?php echo e(date('jS \of F Y', strtotime($lastCheckpoint->created_at))); ?>

                    <?php else: ?>
                        <i>Awaiting Shipment</i>
                    <?php endif; ?>
                </td>
                <td><strong>Last Location:</strong>
                    <?php if(!empty($lastCheckpoint->location)): ?>
                        <?php echo e($lastCheckpoint->location); ?>

                    <?php else: ?>
                        <i>Awaiting Shipment</i>
                    <?php endif; ?>
                </td>
            </tr>
            </tbody>
        </table>

        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Status</th>
                <th scope="col">Location</th>
                <th scope="col">Date</th>
            </tr>
            </thead>
            <tbody>

            <?php if($checkpoints): ?>
                <?php $__currentLoopData = $checkpoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkpoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($checkpoint->status); ?></td>
                        <td><?php echo e($checkpoint->location); ?></td>
                        <td><?php echo e(date('jS \of F Y', strtotime($checkpoint->created_at))); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Awaiting Shipment</p>
            <?php endif; ?>
            </tbody>
        </table>


    </div><!-- /.col-lg-8 -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/shipment-history.blade.php ENDPATH**/ ?>