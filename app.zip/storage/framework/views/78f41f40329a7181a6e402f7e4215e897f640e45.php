<?php $__env->startSection('title'); ?>
    Sign up
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-assets'); ?>
    <script src="<?php echo e(asset('assets/js/countries.js')); ?>" type="text/javascript"></script>

    <style>
        label{
            color: #f1f1f1;
        }

        selector{
            padding-top: 15px;
            padding-bottom: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="breadcrumb-area  margin-bottom-20" style="background-image:url(<?php echo e(asset('assets/img/breadcrumb/01.png')); ?>);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-inner">
                        <h2 class="page-title">Sign up</h2>
                        <ul class="page-list">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="">Sign up</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="header-bottom-area bg-image padding-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <div class="left-content-area">
                        <div class="shipping-area">
                            <div class="section-title white">
                                <h5 class="title">Sign up to get your Tracking id</h5>
                            </div>

                            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <form method="post" action="<?php echo e(route('users.store')); ?>" class="request-page-form margin-top-60">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Name</label>
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Your Name" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Email</label>
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Your Email" value="<?php echo e(old('email')); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Mobile</label>
                                    <div class="form-group">
                                        <input type="tel" name="mobile" class="form-control" placeholder="Mobile Number" value="<?php echo e(old('mobile')); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Country</label>
                                    <select id="country" name="country" class="<?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>State</label>
                                    <select id="state" name="state" class="<?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    </select>
                                </div>
                                <script language="javascript">
                                    populateCountries("country", "state");
                                    populateCountries("country2");
                                </script>

                                <div class="form-group">
                                    <label>Address</label>
                                    <div class="form-group">
                                        <input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo e(old('address')); ?>">
                                    </div>
                                </div>

                                <button type="submit" class="submit-btn">Sign up</button>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-12">
                    <div class="right-content-area">
                        <div class="row">
                            <div class="col-md-6 col-lg-12">
                                <div class="single-header-bottom-item white">
                                    <div class="icon">
                                        <i class="flaticon-online-service"></i>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">24/7 support</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-12">
                                <div class="single-header-bottom-item white">
                                    <div class="icon">
                                        <i class="flaticon-map-4"></i>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Global shipping</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-12">
                                <div class="single-header-bottom-item white">
                                    <div class="icon">
                                        <i class="flaticon-booking"></i>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">On time delivery</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-12">
                                <div class="single-header-bottom-item white">
                                    <div class="icon">
                                        <i class="flaticon-businessman"></i>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Our Expert Team</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/signup.blade.php ENDPATH**/ ?>