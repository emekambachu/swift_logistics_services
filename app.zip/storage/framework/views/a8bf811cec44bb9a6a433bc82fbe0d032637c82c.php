<?php if(Session::has('success')): ?>
    <p align="center" style="padding: 8px 5px 8px 5px; background-color: #5cb85c; color: #fff;" class="col-lg-12"><?php echo e(session('success')); ?></p>
<?php elseif(Session::has('warning')): ?>
    <p align="center" style="padding: 8px 5px 8px 5px; color: #fff;" class="bg-danger col-lg-12"><?php echo e(session('warning')); ?></p>
<?php else: ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/includes/alerts.blade.php ENDPATH**/ ?>