<?php $__env->startSection('title'); ?>
    All Parcels
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-xl-12">
            <div class="card card-sec m-b-30">
                <div class="card-body">

                    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <h4 class="mt-0 m-b-15 header-title">Recent Submission</h4>

                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="thead-dark">
                            <tr class="titles">
                                <th>S/N</th>
                                <th>Name</th>
                                <th>Parcel Number</th>
                                <th>Parcel Weight</th>
                                <th>Description</th>
                                <th>Created</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php if(!empty($parcels)): ?>
                                <?php $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class="c-table__cell"> <?php echo e($loop->iteration); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($par->name); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($par->parcel_number); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($par->weight); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($par->description); ?> </td>
                                        <td class="c-table__cell"><?php echo e(date('jS \of F Y', strtotime($par->created_at))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('parcels.edit', $par->id)); ?>">
                                                <button class="btn btn-circle btn-warning">
                                                    Edit
                                                </button>
                                            </a>
                                        </td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('parcels.destroy', $par->id)); ?>">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-circle btn-danger">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($parcels->links()); ?>


                </div>
            </div>
        </div>

    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\swiftlogservices\resources\views/controlpanel/parcels/index.blade.php ENDPATH**/ ?>