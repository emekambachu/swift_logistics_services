<img src="{{ asset('swiftlog_logo.png') }}" width="120">

<h3>Hello {{ $name }}</h3>

<p>Your account has been successfully created<br><br>
    This will enable us generate your tracking ID.<br>
    You will be contacted by our staff to guide you during this process.
</p><br><br>

<p align="center">
   For more info, contact <i>info@swiftlogservices.com</i>
</p>
