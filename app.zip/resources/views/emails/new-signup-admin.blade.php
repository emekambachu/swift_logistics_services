<img src="{{ asset('swiftlog_logo.png') }}" width="120">

<h3>{{ $name }} Has Signed up</h3>

<p>User Details:<br>
    <strong>Name:</strong> {{ $name }}<br>
    <strong>Email:</strong> {{ $email }}<br>
    <strong>Mobile:</strong> {{ $mobile }}<br>
    <strong>Country:</strong> {{ $country }}<br>
    <strong>State:</strong> {{ $state }}<br>
    <strong>Address:</strong> {{ $address }}<br>
</p>
